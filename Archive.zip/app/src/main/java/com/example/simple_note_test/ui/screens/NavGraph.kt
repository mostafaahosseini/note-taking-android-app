package com.example.simple_note_test.ui.screens

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.NavType
import androidx.navigation.navArgument

@Composable
fun AppNavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = ScreenRoutes.Onboarding.route
    ) {
        composable(ScreenRoutes.Onboarding.route) {
            OnboardingScreen(onGetStarted = {
                navController.navigate(ScreenRoutes.Login.route) {
                    popUpTo(ScreenRoutes.Onboarding.route) { inclusive = true }
                }
            })
        }
        composable(ScreenRoutes.Login.route) { LoginScreen(navController) }
        composable(ScreenRoutes.Register.route) { RegisterScreen(navController) }
        composable(ScreenRoutes.Forgot.route) { ForgotScreen(navController) }
        composable(ScreenRoutes.Home.route) { HomeScreen(navController) }
        composable(ScreenRoutes.NoteDetail.route) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id") ?: ""
            NoteDetailScreen(navController, id)
        }
        composable(ScreenRoutes.NoteEdit.route) {
            NoteEditScreen(navController, null)
        }
        composable(
            route = ScreenRoutes.NoteEdit.editWithId,
            arguments = listOf(
                navArgument("id") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")
            NoteEditScreen(navController, id)
        }
        composable(ScreenRoutes.Settings.route) { SettingsScreen(navController) }
        composable(ScreenRoutes.ChangePassword.route) { ChangePasswordScreen(navController) }
        composable(ScreenRoutes.LogoutConfirm.route) { LogoutConfirmScreen(navController) }
    }
}
