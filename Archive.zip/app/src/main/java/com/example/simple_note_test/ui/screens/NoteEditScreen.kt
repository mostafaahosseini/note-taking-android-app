package com.example.simple_note_test.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import com.example.simple_note_test.ui.theme.Primary
import java.text.SimpleDateFormat
import java.util.*
import androidx.navigation.NavController
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditScreen(navController: NavController, id: String?) {
    val viewModel: NoteEditViewModel = androidx.hilt.navigation.compose.hiltViewModel()
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var lastEditedTime by remember { mutableStateOf<String?>(null) }

    val editState by viewModel.editState.collectAsState()
    val noteState by viewModel.noteState.collectAsState()
    val now = remember { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) }
    var showError by remember { mutableStateOf<String?>(null) }
    val isEditingExistingNote = id != null

    // Load existing note if we're editing
    LaunchedEffect(id) {
        if (id != null) {
            viewModel.loadNote(id)
        }
    }

    // Handle note loading
    LaunchedEffect(noteState) {
        when (val state = noteState) {
            is com.example.simple_note_test.util.NetworkResult.Success -> {
                val note = state.data
                title = note.title
                description = note.description
                lastEditedTime = note.updated_at
                isLoading = false
            }
            is com.example.simple_note_test.util.NetworkResult.Loading -> {
                isLoading = true
            }
            is com.example.simple_note_test.util.NetworkResult.Error -> {
                showError = state.message
                isLoading = false
            }
            else -> { isLoading = false }
        }
    }

    // Handle save/delete success
    LaunchedEffect(editState) {
        when (val state = editState) {
            is com.example.simple_note_test.util.NetworkResult.Success -> {
                navController.navigate(ScreenRoutes.Home.route) {
                    popUpTo(0) { inclusive = true }
                }
            }
            is com.example.simple_note_test.util.NetworkResult.Error -> {
                showError = state.message
            }
            else -> {}
        }
    }

    // Function to save note
    fun saveNote() {
        if (title.isNotBlank() || description.isNotBlank()) {
            if (isEditingExistingNote) {
                viewModel.updateNote(id, title, description)
            } else {
                viewModel.createNote(title, description)
            }
        } else {
            // If both are empty, just navigate back without saving
            navController.popBackStack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = {
                    IconButton(onClick = { saveNote() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Delete icon removed from top app bar
                    if (editState is com.example.simple_note_test.util.NetworkResult.Loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                    }
                }
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = lastEditedTime?.let { "Last updated: $it" } ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(padding)
        ) {
            // Main content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Spacer(modifier = Modifier.height(32.dp))
                BasicTextField(
                    value = title,
                    onValueChange = { title = it },
                    textStyle = TextStyle(
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    decorationBox = { innerTextField ->
                        if (title.isEmpty()) {
                            Text(
                                text = "Title",
                                style = TextStyle(
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.LightGray
                                )
                            )
                        }
                        innerTextField()
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                BasicTextField(
                    value = description,
                    onValueChange = { description = it },
                    textStyle = TextStyle(
                        fontSize = 18.sp,
                        color = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    decorationBox = { innerTextField ->
                        if (description.isEmpty()) {
                            Text(
                                text = "Feel Free to Write Here…",
                                style = TextStyle(
                                    fontSize = 18.sp,
                                    color = Color.LightGray
                                )
                            )
                        }
                        innerTextField()
                    }
                )
                if (showError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = showError!!,
                        color = Color.Red,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            // Floating delete button at bottom right
            if (isEditingExistingNote) {
                FloatingActionButton(
                    onClick = { showDeleteDialog = true },
                    containerColor = Primary,
                    contentColor = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(16.dp)
                ) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete")
                }
            }
            // Show loading indicator while loading existing note
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            // Delete confirmation dialog
            if (showDeleteDialog && isEditingExistingNote) {
                AlertDialog(
                    onDismissRequest = { showDeleteDialog = false },
                    title = { Text("Delete Note") },
                    text = { Text("Are you sure you want to delete this note?") },
                    confirmButton = {
                        TextButton(onClick = {
                            showDeleteDialog = false
                            viewModel.deleteNote(id!!)
                        }) {
                            Text("Delete", color = Color.Red)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDeleteDialog = false }) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }
    }
}
