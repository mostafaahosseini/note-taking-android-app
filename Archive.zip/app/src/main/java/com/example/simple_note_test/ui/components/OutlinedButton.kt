package com.example.simple_note_test.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.simple_note_test.ui.theme.NotesShapes
import com.example.simple_note_test.ui.theme.Primary
import com.example.simple_note_test.ui.theme.GreyBase
import com.example.simple_note_test.ui.theme.White

@Composable
fun OutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onDark: Boolean = false,                 // اگر پس‌زمینه تیره/بنفش است = true
    trailingIcon: (@Composable (() -> Unit))? = null
) {
    val contentColor = if (onDark) White else Primary
    val borderColor = if (onDark) White else GreyBase

    androidx.compose.material3.OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = NotesShapes.large,
        border = BorderStroke(1.dp, borderColor),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = Color.Transparent,
            contentColor = contentColor,
            disabledContentColor = contentColor.copy(alpha = 0.4f)
        ),
        modifier = modifier
            .height(54.dp)
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text, style = MaterialTheme.typography.bodyLarge, color = contentColor)
            if (trailingIcon != null) {
                Spacer(modifier = Modifier.width(8.dp))
                // آیکن رنگ را از LocalContentColor می‌گیرد
                CompositionLocalProvider(LocalContentColor provides contentColor) {
                    trailingIcon()
                }
            }
        }
    }
}
