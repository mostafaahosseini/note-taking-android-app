package com.example.simple_note_test.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simple_note_test.ui.components.NotesTextField
import com.example.simple_note_test.ui.components.OutlinedButton
import com.example.simple_note_test.ui.theme.GreyBase
import com.example.simple_note_test.ui.theme.GreyDark
import com.example.simple_note_test.ui.theme.Primary
import androidx.navigation.NavController
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.material3.CircularProgressIndicator
import com.example.simple_note_test.util.NetworkResult

@Composable
fun LoginScreen(navController: NavController, viewModel: LoginViewModel = hiltViewModel()) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val loginState by viewModel.loginState.collectAsState()
    var showError by remember { mutableStateOf<String?>(null) }

    // Handle navigation on success
    LaunchedEffect(loginState) {
        val success = loginState as? NetworkResult.Success
        if (success != null && success.data == true) {
            navController.navigate("home") {
                popUpTo(0) { inclusive = true }
            }
        } else if (loginState is NetworkResult.Error) {
            showError = (loginState as NetworkResult.Error).message
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(48.dp))
            Text(
                text = "Let’s Login",
                style = MaterialTheme.typography.displayLarge.copy(
                    color = Color(0xFF180E25),
                    fontWeight = FontWeight.Bold,
                    fontSize = 32.sp
                ),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Start
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "And notes your idea",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = GreyDark,
                    fontWeight = FontWeight.Normal,
                    fontSize = 16.sp
                ),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Start
            )
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "Username",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = Color(0xFF180E25),
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            NotesTextField(
                value = username,
                onValueChange = { username = it },
                placeholder = "Example: johndoe",
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Password",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = Color(0xFF180E25),
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            NotesTextField(
                value = password,
                onValueChange = { password = it },
                placeholder = "********",
                isPassword = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(32.dp))
            OutlinedButton(
                text = if (loginState is NetworkResult.Loading) "Logging in..." else "Login",
                onClick = { viewModel.login(username, password) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                enabled = loginState !is NetworkResult.Loading,
                trailingIcon = {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Arrow",
                        tint = Color.White
                    )
                }
            )
            if (loginState is NetworkResult.Loading) {
                Spacer(modifier = Modifier.height(16.dp))
                CircularProgressIndicator()
            }
            if (showError != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = showError!!,
                    color = Color.Red,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f), color = GreyBase)
                Text(
                    text = "  Or  ",
                    color = GreyBase,
                    fontSize = 14.sp
                )
                HorizontalDivider(modifier = Modifier.weight(1f), color = GreyBase)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Don’t have any account? Register here",
                color = Primary,
                fontSize = 16.sp,
                modifier = Modifier
                    .clickable { navController.navigate(ScreenRoutes.Register.route) }
                    .fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        }
    }
}
