Remote data sources (Retrofit interfaces, DTOs) go here.

