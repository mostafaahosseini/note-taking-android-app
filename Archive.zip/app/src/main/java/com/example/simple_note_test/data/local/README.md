Local data sources (Room DAOs, entities) go here.

