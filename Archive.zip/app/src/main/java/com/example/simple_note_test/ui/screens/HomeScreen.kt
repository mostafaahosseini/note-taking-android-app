package com.example.simple_note_test.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.simple_note_test.ui.components.NoteCard
import com.example.simple_note_test.util.NetworkResult

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(navController: NavController, viewModel: HomeViewModel = hiltViewModel()) {
    val notesState by viewModel.notesState.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    // Pastel/yellowish color palette for note cards
    val noteColors = listOf(
        Color(0xFFFFF9C4), // Light Yellow
        Color(0xFFFFF8E1), // Cream
        Color(0xFFFFFDE7), // Very Light Yellow
        Color(0xFFFFF3E0), // Light Orange
        Color(0xFFE1F5FE), // Light Blue
        Color(0xFFE8F5E9), // Light Green
        Color(0xFFF3E5F5), // Light Purple
        Color(0xFFFFEBEE)  // Light Pink
    )

    // Redirect to Login if no access token
    LaunchedEffect(notesState) {
        if (notesState is NetworkResult.Error && (notesState as NetworkResult.Error).message.contains("No access token found")) {
            navController.navigate(ScreenRoutes.Login.route) {
                popUpTo(0) { inclusive = true }
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.loadNotes()
    }

    Scaffold(
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().background(Color.White)) {
                Spacer(modifier = Modifier.height(16.dp))
                TextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search…") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Notes",
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        },
        floatingActionButton = {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                FloatingActionButton(onClick = { navController.navigate(ScreenRoutes.NoteEdit.route) }) {
                    Icon(imageVector = Icons.Filled.Add, contentDescription = "Add Note")
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    selected = true,
                    onClick = { }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    selected = false,
                    onClick = { navController.navigate(ScreenRoutes.Settings.route) }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (notesState) {
                is NetworkResult.Loading -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
                is NetworkResult.Error -> {
                    Text(
                        text = (notesState as NetworkResult.Error).message,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                is NetworkResult.Success -> {
                    val notes = (notesState as NetworkResult.Success<List<com.example.simple_note_test.data.models.NoteResponse>>).data
                        .filter { it.title.contains(searchQuery, ignoreCase = true) || it.description.contains(searchQuery, ignoreCase = true) }
                    if (notes.isEmpty()) {
                        Text(
                            text = "No notes yet.",
                            modifier = Modifier.align(Alignment.Center)
                        )
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(16.dp)
                        ) {
                            items(notes.size) { index ->
                                val note = notes[index]
                                val color = noteColors[index % noteColors.size]
                                NoteCard(
                                    title = note.title,
                                    preview = note.description,
                                    lastEdited = note.updated_at,
                                    onClick = { navController.navigate(ScreenRoutes.NoteEdit.createRoute(note.id)) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .wrapContentHeight(),
                                    backgroundColor = color
                                )
                            }
                        }
                    }
                }
                else -> {
                    // Handle Idle or unknown state
                }
            }
        }
    }
}
