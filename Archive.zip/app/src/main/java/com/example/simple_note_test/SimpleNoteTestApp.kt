package com.example.simple_note_test

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SimpleNoteTestApp : Application()

