Utility classes and helpers go here.

