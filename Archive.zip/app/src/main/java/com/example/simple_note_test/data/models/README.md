Shared data models (domain, UI, etc) go here.

